import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DatosPersona } from '../app.model';


@Injectable({ providedIn: 'root' })
export class ApiService {
    private http = inject(HttpClient);
    private apiUrl = 'http://localhost:3000/api';

    // --- DATOS CRUD ---
    getDatos(): Observable<DatosPersona[]> {
        return this.http.get<DatosPersona[]>(`${this.apiUrl}/datos`);
    }

    getDatoById(id: number): Observable<DatosPersona> {
        return this.http.get<DatosPersona>(`${this.apiUrl}/datos/${id}`);
    }

    crearDato(dato: any): Observable<any> {
        return this.http.post(`${this.apiUrl}/datos`, dato);
    }

    editarDato(id: number, dato: any): Observable<any> {
        return this.http.put(`${this.apiUrl}/datos/${id}`, dato);
    }

    eliminarDato(id: number): Observable<any> {
        return this.http.delete(`${this.apiUrl}/datos/${id}`);
    }

    // --- ADMIN ---
    getBitacora(): Observable<any[]> {
        return this.http.get<any[]>(`${this.apiUrl}/bitacora`);
    }

    crearUsuarioAdmin(usuario: any): Observable<any> {
        return this.http.post(`${this.apiUrl}/admin/usuarios`, usuario);
    }
}