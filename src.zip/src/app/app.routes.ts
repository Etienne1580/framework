import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { Dashboard } from './components/dashboard/dashboard';

export const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'dashboard', component: Dashboard },
    // Agrega aquí las demás rutas conforme las vayas creando (nuevo usuario, bitácora, etc.)
    { path: '**', redirectTo: 'login' }
];