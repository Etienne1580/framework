// src/app/app.models.ts

export interface Usuario {
    idUsuarios: number;
    nombreUsuarios: string;
    privilegiosUsuarios: number;
}

export interface DatosPersona {
    idDatos: number;
    nombreDatos: string;
    edadDatos: number;
    sexoDatos: number; // 1 = Hombre, 2 = Mujer, etc.
    fechaNacimientoDatos: string;
    correoDatos: string;
}

// Mapa exacto de tu requerimiento de bits
export enum Privilegios {
    NUEVO = 1,
    DESPLEGAR = 2,
    EDITAR = 4,
    ELIMINAR = 8,
    ADMIN = 16
}