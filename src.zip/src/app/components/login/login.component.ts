import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './login.component.html',
    styleUrl: './login.component.css'
})
export class LoginComponent {
    authService = inject(AuthService);
    router = inject(Router);

    nombre = '';
    clave = '';
    errorMessage = '';

    onLogin() {
        this.authService.login(this.nombre, this.clave).subscribe({
            next: (res) => {
                if (res.success) {
                    // Redirige al Dashboard al validar correctamente con la base de datos
                    this.router.navigate(['/dashboard']);
                } else {
                    this.errorMessage = 'Credenciales incorrectas';
                }
            },
            error: () => {
                this.errorMessage = 'Error de conexión con el servidor intermediario';
            }
        });
    }
}