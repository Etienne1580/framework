import { Component } from '@angular/core';

@Component({
  selector: 'app-datos-detail',
  imports: [],
  templateUrl: './datos-detail.html',
  styleUrl: './datos-detail.css',
})
export class DatosDetail {}
