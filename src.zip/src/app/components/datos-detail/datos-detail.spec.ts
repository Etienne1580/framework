import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosDetail } from './datos-detail';

describe('DatosDetail', () => {
  let component: DatosDetail;
  let fixture: ComponentFixture<DatosDetail>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DatosDetail],
    }).compileComponents();

    fixture = TestBed.createComponent(DatosDetail);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
