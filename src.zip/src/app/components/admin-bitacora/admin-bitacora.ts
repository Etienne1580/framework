import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-bitacora',
  imports: [],
  templateUrl: './admin-bitacora.html',
  styleUrl: './admin-bitacora.css',
})
export class AdminBitacora {}
