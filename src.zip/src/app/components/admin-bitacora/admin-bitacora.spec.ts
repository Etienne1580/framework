import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBitacora } from './admin-bitacora';

describe('AdminBitacora', () => {
  let component: AdminBitacora;
  let fixture: ComponentFixture<AdminBitacora>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminBitacora],
    }).compileComponents();

    fixture = TestBed.createComponent(AdminBitacora);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
