import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { DatosPersona } from '../../app.model';
import { Privilegios } from '../../app.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  apiService = inject(ApiService);
  authService = inject(AuthService);
  router = inject(Router);

  datosLista: DatosPersona[] = [];
  selectedId: number | null = null;
  Priv = Privilegios; // Exponemos el enum al HTML

  ngOnInit() {
    this.cargarDatos();
  }

  cargarDatos() {
    this.apiService.getDatos().subscribe(res => {
      this.datosLista = res;
    });
  }

  seleccionar(id: number) {
    this.selectedId = id;
  }

  ejecutarAccion(accion: string) {
    if (accion === 'nuevo') this.router.navigate(['/datos/nuevo']);
    if (accion === 'desplegar' && this.selectedId) this.router.navigate(['/datos/desplegar', this.selectedId]);
    if (accion === 'editar' && this.selectedId) this.router.navigate(['/datos/editar', this.selectedId]);

    if (accion === 'eliminar' && this.selectedId) {
      if (confirm('¿Eliminar registro?')) {
        this.apiService.eliminarDato(this.selectedId).subscribe(() => {
          this.cargarDatos();
          this.selectedId = null;
        });
      }
    }
  }
}